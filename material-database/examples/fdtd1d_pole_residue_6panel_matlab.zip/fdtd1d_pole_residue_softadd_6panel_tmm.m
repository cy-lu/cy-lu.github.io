%% 1D FDTD PoleResidue JSON example with compact 6-panel validation summary
% -------------------------------------------------------------------------
% PURPOSE
%   Minimal 1D dispersive-film FDTD reference for downloaded PoleResidue JSON
%   material models.  The script uses a synchronized two-row soft-add run:
%
%       row 1 = vacuum reference grid
%       row 2 = material-film grid
%
%   The same source, boundary condition, monitor locations, and DFT phasors
%   are used in both rows.  Reflection is extracted from the difference
%   between material and vacuum fields at the reflection monitor, while
%   transmission is read from the material-grid transmission monitor.
%
% MODEL CONVENTION
%   The input JSON is a PoleResidue dielectric model using exp(-j*w*t):
%
%       eps(w) = eps_inf - sum_m [ c_m/(j*w+a_m)
%                                + conj(c_m)/(j*w+conj(a_m)) ].
%
%   The script uses the coefficients directly.  Do not flip the signs of a_m
%   or c_m when using native Tidy3D/PoleResidue exports.
%
% ADE UPDATE
%   Only the centered-Q ADE update is kept in this public reference version:
%
%       Q = P/eps0
%       Q^{n+1} = alpha Q^n + beta E^n + beta E^{n+1}
%       alpha = (1+a*dt/2)/(1-a*dt/2)
%       beta  = (c*dt/2)/(1-a*dt/2)
%
%   This public reference file contains only the FDTD update and the optional TMM comparison.
%
% TMM COMPARISON
%   Set RUN_TMM_REFERENCE = true to compare the FDTD R/T/A spectra with a
%   transfer-matrix reference for the same single film.  The TMM helper file
%   tmm1d_transfer_matrix_reference.m must be in the same folder or on the
%   MATLAB path.
%
% BOUNDARY CONDITIONS
%   CPML is the intended open-boundary setting for R/T/A validation.  PEC and
%   PBC are retained as simple debugging options; their spectra should not be
%   interpreted as open-boundary TMM results.
% -------------------------------------------------------------------------

clear; close all; clc;
script_dir = fileparts(mfilename('fullpath'));
if isempty(script_dir), script_dir = pwd; end
cd(script_dir);

%% USER CONTROLS
% -------------------------------------------------------------------------
% Change only this block for a normal single-case test.
% -------------------------------------------------------------------------

% --- Material model ---
JSON_FILE  = 'pole_residue_model.json';
MODEL_NAME = 'RP_M3';              % e.g. RP_M1, RP_M2, ...
CASE_TAG   = 'manual_case';        % output filename tag; no spaces preferred

% --- FDTD setup ---
BOUNDARY_MODE = 'CPML';            % 'CPML' for open-boundary R/T/A validation

film_thickness_nm = 200;
lambda_min_nm     = 300;
lambda_max_nm     = 1100;
lambda_focus_nm   = 450;

dx_nm  = 5.0;
CFL    = 0.75;
NSTEPS = 300000;
nfreq  = 801;

npml   = 36;
cpml_m       = 3;
cpml_R0      = 1e-8;
left_air_nm  = 400;
right_air_nm = 400;

% --- Optional TMM reference ---
RUN_TMM_REFERENCE = true;          % true: include TMM reference in the 6-panel summary
PROMPT_FOR_TMM    = false;         % true: ask in Command Window after FDTD run

% --- Output ---
OUTDIR = fullfile(script_dir, ['TEST_' CASE_TAG '_' MODEL_NAME]);
if ~exist(OUTDIR,'dir'), mkdir(OUTDIR); end

%% CONSTANTS AND SETUP
c0   = 2.99792458e8;
eps0 = 8.854187817e-12;
mu0  = 4*pi*1e-7;
z0   = sqrt(mu0/eps0);

mat = load_pr_json(fullfile(script_dir,JSON_FILE),MODEL_NAME);
p   = setup_grid(c0,eps0,mu0,dx_nm,CFL,NSTEPS,nfreq,film_thickness_nm, ...
                 lambda_min_nm,lambda_max_nm,npml,cpml_m,cpml_R0, ...
                 left_air_nm,right_air_nm,BOUNDARY_MODE);
p.ade_mode = 'centered_Q';

fprintf('\n[1D SOFT-ADD FDTD: PoleResidue centered-Q ADE]\n');
fprintf('  JSON/model        : %s / %s\n', JSON_FILE, MODEL_NAME);
fprintf('  eps_inf           : %.12g\n', mat.eps_inf);
fprintf('  half poles/states : %d / %d\n', mat.npoles_half, mat.naux);
fprintf('  ADE update        : centered-Q only\n');
fprintf('  boundary mode     : %s\n', p.boundary_mode);
fprintf('  film              : %.3f nm = %d cells\n', film_thickness_nm, p.nfilm);
fprintf('  dx/CFL/dt         : %.3f nm / %.3f / %.4e s\n', dx_nm, CFL, p.dt);
fprintf('  KE/NSTEPS         : %d / %d\n', p.KE, p.NSTEPS);
if strcmp(p.boundary_mode,'CPML')
    fprintf('  CPML              : %d cells per side, %.3f nm per side\n', p.nbc, p.pml_thickness_nm);
else
    fprintf('  CPML              : inactive; using %s end boundary\n', p.boundary_mode);
end
fprintf('  positions         : src=%d, ref=%d, slab=[%d:%d], trn=%d\n', ...
        p.src_pos, p.ref_pos, p.mat_i1, p.mat_i2, p.trn_pos);

if strcmp(p.boundary_mode,'CPML') && p.pml_thickness_nm < 150
    warning('CPML physical thickness is only %.1f nm. Consider increasing npml or dx for broadband validation.', p.pml_thickness_nm);
end
if ~strcmp(p.boundary_mode,'CPML')
    warning('%s boundary selected: use this only for debugging. Open-boundary R/T/A comparison requires CPML.', p.boundary_mode);
end

%% RUN FDTD
out = run_softadd_dual_ADE(p,mat,eps0,mu0);
[Rf,Tf,Af,diag] = extract_rta_px(out);
lambda_nm = p.lambda_nm(:);

eps_fit    = eps_pr(p.OMEGA(:),mat);
n_material = sqrt_branch_passive(eps_fit);

%% OPTIONAL TMM COMPARISON
run_tmm = RUN_TMM_REFERENCE;
if PROMPT_FOR_TMM
    reply = input('Run TMM comparison now? [Y]/n: ','s');
    run_tmm = isempty(reply) || any(strcmpi(strtrim(reply),{'y','yes'}));
end

Rt = nan(size(Rf)); Tt = nan(size(Tf)); At = nan(size(Af));
nominal_err = [];
if run_tmm
    [eps_fit,n_material,Rt,Tt,At] = tmm_reference(p,mat,z0,film_thickness_nm);
    nominal_err = rta_error_metrics(lambda_nm,Rf,Tf,Af,Rt,Tt,At);
end

[~,ifocus] = min(abs(lambda_nm-lambda_focus_nm));

fprintf('\n[FOCUS %.3f nm]\n', lambda_nm(ifocus));
fprintf('  eps        = %.8g %+.8gi\n', real(eps_fit(ifocus)), imag(eps_fit(ifocus)));
fprintf('  FDTD R,T,A = %.6g, %.6g, %.6g\n', Rf(ifocus), Tf(ifocus), Af(ifocus));
if run_tmm
    fprintf('  TMM  R,T,A = %.6g, %.6g, %.6g\n', Rt(ifocus), Tt(ifocus), At(ifocus));
    fprintf('  abs err    = %.3e, %.3e, %.3e\n', ...
            abs(Rf(ifocus)-Rt(ifocus)), abs(Tf(ifocus)-Tt(ifocus)), abs(Af(ifocus)-At(ifocus)));
end
fprintf('  median Px  = inc_ref %.4e, inc_trn %.4e, ref %.4e, trn %.4e\n', ...
        median(diag.Px_inc_ref), median(diag.Px_inc_trn), median(diag.Px_ref), median(diag.Px_trn));

if run_tmm
    fprintf('\n[GLOBAL R/T/A MATCH: nominal %.3f nm TMM]\n', film_thickness_nm);
    fprintf('  Emax_RTA = %.6g, Erms_RTA = %.6g\n', nominal_err.Emax_RTA, nominal_err.Erms_RTA);
    fprintf('  Emax_R/T/A = %.6g, %.6g, %.6g\n', nominal_err.Emax_R, nominal_err.Emax_T, nominal_err.Emax_A);
    fprintf('  max channel = %s at %.6g nm, max error = %.6g\n', ...
            nominal_err.max_channel, nominal_err.max_lambda_nm, nominal_err.max_error);
else
    fprintf('\n[TMM comparison disabled]\n');
end

%% SAVE AND PLOT
[~,stem,~] = fileparts(JSON_FILE);
thick_tag = strrep(sprintf('%.6gnm',film_thickness_nm),'.','p');
bc_tag = boundary_mode_tag(p.boundary_mode);
prefix_base = sprintf('%s_%s_%s_centeredADE_%s_%s_dx%gnm_CFL%g', ...
                      CASE_TAG, stem, MODEL_NAME, bc_tag, thick_tag, dx_nm, CFL);
prefix = fullfile(OUTDIR, prefix_base);

if run_tmm
    write_match_summary(prefix,nominal_err,film_thickness_nm);
    writematrix([lambda_nm,Rf,Tf,Af,Rt,Tt,At,real(eps_fit),imag(eps_fit),real(n_material),imag(n_material)], ...
                [prefix '_RTA_TMM.dat'], 'Delimiter','tab');
else
    writematrix([lambda_nm,Rf,Tf,Af,real(eps_fit),imag(eps_fit),real(n_material),imag(n_material)], ...
                [prefix '_RTA_FDTD.dat'], 'Delimiter','tab');
end

writematrix([lambda_nm, ...
    real(out.mat.Ex_ref),imag(out.mat.Ex_ref),real(out.mat.Hy_ref),imag(out.mat.Hy_ref), ...
    real(out.mat.Ex_trn),imag(out.mat.Ex_trn),real(out.mat.Hy_trn),imag(out.mat.Hy_trn), ...
    real(out.vac.Ex_ref),imag(out.vac.Ex_ref),real(out.vac.Hy_ref),imag(out.vac.Hy_ref), ...
    real(out.vac.Ex_trn),imag(out.vac.Ex_trn),real(out.vac.Hy_trn),imag(out.vac.Hy_trn)], ...
    [prefix '_monitors.dat'], 'Delimiter','tab');

% Final 2x3 validation summary figure.
% The public output is intentionally compact:
%   (a) normalized source spectrum
%   (b) material n,k from the PoleResidue model
%   (c) Re/Im permittivity from the PoleResidue model
%   (d) FDTD result, overlaid with TMM when enabled
%   (e) absolute FDTD-TMM difference when enabled
%   (f) time-domain convergence monitor
summary_png = [prefix '_summary_6panel.png'];
fig = figure('Color','w','Position',[80 80 1600 900],'Visible','on');

subplot(2,3,1);
src_spec = abs(out.vac.SN(:)).^2;
src_spec = src_spec ./ max(src_spec + eps);
plot(lambda_nm,src_spec,'k','LineWidth',1.5); grid on;
xlabel('\lambda (nm)'); ylabel('Normalized power');
title('(a) Source spectrum');
axis([min(lambda_nm) max(lambda_nm) 0 1.05]);

subplot(2,3,2);
plot(lambda_nm,real(n_material),'b','LineWidth',1.5); hold on;
plot(lambda_nm,imag(n_material),'r','LineWidth',1.5); grid on;
xlabel('\lambda (nm)'); ylabel('n, k');
legend('n','k','Location','best');
title('(b) PoleResidue material');

subplot(2,3,3);
plot(lambda_nm,real(eps_fit),'b','LineWidth',1.5); hold on;
plot(lambda_nm,imag(eps_fit),'r','LineWidth',1.5); grid on;
xlabel('\lambda (nm)'); ylabel('\epsilon');
legend('Re \epsilon','Im \epsilon','Location','best');
title('(c) Permittivity model');

subplot(2,3,4);
plot(lambda_nm,Rf,'r','LineWidth',1.5); hold on;
plot(lambda_nm,Tf,'b','LineWidth',1.5);
plot(lambda_nm,Af,'k','LineWidth',1.3);
if run_tmm
    plot(lambda_nm,Rt,'r--','LineWidth',1.2);
    plot(lambda_nm,Tt,'b--','LineWidth',1.2);
    plot(lambda_nm,At,'k--','LineWidth',1.1);
    legend('R FDTD','T FDTD','A FDTD','R TMM','T TMM','A TMM','Location','best');
    title('(d) FDTD vs TMM: R/T/A');
else
    legend('R FDTD','T FDTD','A FDTD','Location','best');
    title('(d) 1D FDTD result: R/T/A');
end
grid on; xlabel('\lambda (nm)'); ylabel('Coefficient');
axis([min(lambda_nm) max(lambda_nm) 0 1]);

subplot(2,3,5);
if run_tmm
    eR = abs(Rf(:)-Rt(:));
    eT = abs(Tf(:)-Tt(:));
    eA = abs(Af(:)-At(:));
    plot(lambda_nm,eR,'r','LineWidth',1.3); hold on;
    plot(lambda_nm,eT,'b','LineWidth',1.3);
    plot(lambda_nm,eA,'k','LineWidth',1.2);
    yl = ylim;
    line([nominal_err.max_lambda_nm nominal_err.max_lambda_nm], yl, ...
         'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',1.0);
    grid on; xlabel('\lambda (nm)'); ylabel('Absolute difference');
    legend('|Delta R|','|Delta T|','|Delta A|','Max','Location','best');
    title(sprintf('(e) |FDTD - TMM|, Erms=%.3g', nominal_err.Erms_RTA));
else
    axis off;
    text(0.08,0.58,'TMM comparison disabled','FontSize',13);
    text(0.08,0.44,'Set RUN_TMM_REFERENCE = true to show this panel.','FontSize',11);
    title('(e) FDTD-TMM difference');
end

subplot(2,3,6);
semilogy(out.mat.max_abs_E_history(:)+eps,'LineWidth',1.2); hold on;
semilogy(abs(out.mat.probe_signal(:))+eps,'LineWidth',1.0); grid on;
xlabel('Time step'); ylabel('Amplitude');
legend('max |E|','|probe|','Location','best');
title('(f) Time-domain convergence');

sgtitle(sprintf('%s | %.3f nm film | %s boundary', CASE_TAG, film_thickness_nm, p.boundary_mode), ...
        'Interpreter','none');
saveas(fig,summary_png);

fprintf('\nWrote outputs under:\n  %s\n', OUTDIR);
if run_tmm
    fprintf('Main files:\n  %s_match_summary.txt\n  %s_RTA_TMM.dat\n  %s_summary_6panel.png\n', prefix, prefix, prefix);
else
    fprintf('Main files:\n  %s_RTA_FDTD.dat\n  %s_summary_6panel.png\n', prefix, prefix);
end

%% ============================ FUNCTIONS ============================
function mode = normalize_boundary_mode(s)
    s = upper(strtrim(string(s)));
    if s=="CPML" || s=="PML" || s=="OPEN"
        mode = 'CPML';
    elseif s=="PEC"
        mode = 'PEC';
    elseif s=="PBC" || s=="PERIODIC"
        mode = 'PBC';
    else
        error('Unknown BOUNDARY_MODE = %s. Use CPML, PEC, or PBC.', s);
    end
end

function tag = boundary_mode_tag(mode)
    mode = normalize_boundary_mode(mode);
    if strcmp(mode,'CPML')
        tag = 'CPML';
    elseif strcmp(mode,'PEC')
        tag = 'PEC';
    else
        tag = 'PBC';
    end
end

function p = setup_grid(c0,eps0,mu0,dx_nm,CFL,NSTEPS,nfreq,film_nm,lmin_nm,lmax_nm,npml,m,R0,left_nm,right_nm,boundary_mode)
    p.ddx = dx_nm*1e-9;
    p.dt  = CFL*p.ddx/c0;
    p.NSTEPS = NSTEPS;
    p.nfreq  = nfreq;
    p.nfilm  = round(film_nm/dx_nm);
    p.boundary_mode = normalize_boundary_mode(boundary_mode);
    p.npml_requested = npml;
    if strcmp(p.boundary_mode,'CPML')
        p.nbc = npml;
    else
        p.nbc = 0;
    end
    p.pml_thickness_nm = p.nbc*dx_nm;

    nL = round(left_nm/dx_nm);
    nR = round(right_nm/dx_nm);
    p.KE = 2*p.nbc + nL + p.nfilm + nR;

    p.mat_i1 = p.nbc + nL + 1;
    p.mat_i2 = p.mat_i1 + p.nfilm - 1;

    p.src_pos = p.nbc + max(5,round(0.25*nL));
    p.ref_pos = p.nbc + max(round(0.25*nL)+10,round(0.65*nL));
    right_guard = max(5,p.nbc+5);
    p.trn_pos = min(max(p.mat_i2,p.ref_pos) + max(5,round(0.35*nR)), p.KE-right_guard);

    if p.nfilm > 0
        ok = p.src_pos < p.ref_pos && p.ref_pos < p.mat_i1 && ...
             p.mat_i2 < p.trn_pos && p.trn_pos < p.KE;
    else
        ok = p.src_pos < p.ref_pos && p.ref_pos < p.trn_pos && p.trn_pos < p.KE;
    end
    if strcmp(p.boundary_mode,'CPML')
        ok = ok && p.nbc < p.src_pos && p.trn_pos < p.KE-p.nbc;
    elseif strcmp(p.boundary_mode,'PEC')
        ok = ok && 1 < p.src_pos && p.trn_pos < p.KE;
    end
    if ~ok
        error('Bad geometry: bc=%s src=%d ref=%d slab=[%d:%d] trn=%d KE=%d nbc=%d', ...
              p.boundary_mode,p.src_pos,p.ref_pos,p.mat_i1,p.mat_i2,p.trn_pos,p.KE,p.nbc);
    end

    p.lambda_nm = logspace(log10(lmin_nm),log10(lmax_nm),nfreq).';
    p.freq_hz   = c0 ./ (p.lambda_nm*1e-9);
    p.OMEGA     = 2*pi*p.freq_hz;
    p.tau       = 2.5/max(p.OMEGA);
    p.to        = 8*p.tau;
    if strcmp(p.boundary_mode,'CPML')
        p.cpml = make_cpml_1d(p.KE,p.nbc,p.ddx,p.dt,eps0,mu0,m,R0);
    else
        p.cpml = make_no_cpml_1d(p.KE);
    end
end

function out = run_softadd_dual_ADE(p,mat,eps0,mu0)
    KE = p.KE;
    dt = p.dt;
    dx = p.ddx;
    cb = dt/(eps0*dx);
    db = dt/(mu0*dx);

    bc = normalize_boundary_mode(p.boundary_mode);
    use_cpml = strcmp(bc,'CPML');
    if use_cpml
        bE = p.cpml.bE; cE = p.cpml.cE; kEi = p.cpml.kEi;
        bH = p.cpml.bH; cH = p.cpml.cH; kHi = p.cpml.kHi;
    end

    % Row 1 is vacuum, row 2 is material.  The same source and boundary
    % operations are applied to both rows; only the material row receives
    % the selected ADE override in the slab cells.
    Ex   = zeros(2,KE);
    Hz   = zeros(2,KE);
    psiE = zeros(2,KE);
    psiH = zeros(2,KE-1);

    a = mat.a_full(:);
    c = mat.c_full(:);
    M = numel(a);
    eps_inf = real(mat.eps_inf);
    fprintf('\n[BOUNDARY RUNTIME] %s boundary selected\n', bc);
    if ~strcmp(bc,'CPML')
        fprintf('  note: %s is useful for debugging; open-boundary R/T/A validation requires CPML.\n', bc);
    end

    % Centered-Q ADE only.  This reference script intentionally removes the
    % additional diagnostic branches used in private development versions.
    den   = 1 - 0.5*a*dt;
    alpha = (1 + 0.5*a*dt) ./ den;
    beta  = (0.5*c*dt) ./ den;
    denE  = eps_inf + real(sum(beta));
    Aux   = complex(zeros(M,KE));       % Q=P/eps0 state for centered-Q ADE

    fprintf('\n[ADE RUNTIME] centered-Q ADE selected\n');
    fprintf('  state = Q=P/eps0, beta=(c*dt/2)/(1-a*dt/2), denE=eps_inf+Re(sum beta)\n');
    fprintf('  min |1-a dt/2| = %.6e\n', min(abs(den)));
    fprintf('  max |alpha|    = %.12g\n', max(abs(alpha)));
    fprintf('  max |beta|     = %.12g\n', max(abs(beta)));
    fprintf('  denE           = %.12g\n', denE);

    if max(abs(alpha)) > 1 + 1e-10
        warning('Material recurrence has max |alpha| = %.6g > 1.', max(abs(alpha)));
    end
    if abs(denE) < 1e-12
        warning('Small material E denominator: %.6e.', denE);
    end

    if p.nfilm > 0 && p.mat_i2 >= p.mat_i1
        midx = p.mat_i1:p.mat_i2;
        probe_idx = round((midx(1)+midx(end))/2);
    else
        midx = [];
        probe_idx = p.ref_pos;
    end

    SN = zeros(p.nfreq,1);
    Er = zeros(p.nfreq,2); Et = Er;
    Hr = zeros(p.nfreq,2); Ht = Er;
    maxE = zeros(2,p.NSTEPS);
    probeSig = zeros(2,p.NSTEPS);

    phase = ones(p.nfreq,1);
    phase_step = exp(-1i*p.OMEGA(:)*dt);

    for n = 1:p.NSTEPS
        % H/E update with selected end boundary, first as if both rows were vacuum.
        Ex_old = Ex;
        if use_cpml
            % CPML/open boundary: standard lossy-layer auxiliary variables.
            dE = Ex(:,2:KE) - Ex(:,1:KE-1);
            psiH = psiH.*bH + dE.*cH;
            Hz(:,1:KE-1) = Hz(:,1:KE-1) + db*(dE.*kHi + psiH);

            dH = Hz(:,2:KE) - Hz(:,1:KE-1);
            dH_full = [zeros(2,1), dH];
            psiE = psiE.*bE + dH_full.*cE;
            Ex = Ex + cb*(dH_full.*kEi + psiE);

        elseif strcmp(bc,'PEC')
            % PEC closed boundary: tangential E is forced to zero at both ends.
            dE = Ex(:,2:KE) - Ex(:,1:KE-1);
            Hz(:,1:KE-1) = Hz(:,1:KE-1) + db*dE;
            Hz(:,KE) = 0;

            dH = Hz(:,2:KE-1) - Hz(:,1:KE-2);
            Ex(:,2:KE-1) = Ex(:,2:KE-1) + cb*dH;
            Ex(:,[1 KE]) = 0;

        else
            % PBC/periodic boundary: right-going waves re-enter from the left.
            dE = [Ex(:,2:KE)-Ex(:,1:KE-1), Ex(:,1)-Ex(:,KE)];
            Hz = Hz + db*dE;

            dH_full = [Hz(:,1)-Hz(:,KE), Hz(:,2:KE)-Hz(:,1:KE-1)];
            Ex = Ex + cb*dH_full;
        end

        % Selected ADE implicit correction in material cells, material row only.
        if ~isempty(midx) && M > 0
            curl = Ex(2,midx) - Ex_old(2,midx);
            Aold = Aux(:,midx);
            % Centered-Q ADE: Q^{n+1}=alpha Q^n+beta E^n+beta E^{n+1}.
            Dold  = eps_inf*Ex_old(2,midx) + real(sum(Aold,1));
            Qstar = alpha.*Aold + beta.*Ex_old(2,midx);
            Ex(2,midx) = (Dold + curl - real(sum(Qstar,1))) / denE;
            Aux(:,midx) = Qstar + beta.*Ex(2,midx);
        end

        % Soft-add E source.  Same waveform and timing on both grids.
        tt = (n*dt - p.to)/p.tau;
        pulse = -2*tt*exp(-tt*tt);
        Ex(:,p.src_pos) = Ex(:,p.src_pos) + pulse;
        if strcmp(bc,'PEC')
            Ex(:,[1 KE]) = 0;
        end

        if bitand(n,1023)==0
            if any(~isfinite(Ex(:))) || any(~isfinite(Hz(:))) || any(~isfinite(Aux(:)))
                error('Divergence/NaN at time step %d.', n);
            end
        end

        % DFT accumulation, exp(-j*w*t), same phasor for both grids.
        SN = SN + pulse*phase;
        Er(:,1) = Er(:,1) + Ex(1,p.ref_pos)*phase;
        Er(:,2) = Er(:,2) + Ex(2,p.ref_pos)*phase;
        Et(:,1) = Et(:,1) + Ex(1,p.trn_pos)*phase;
        Et(:,2) = Et(:,2) + Ex(2,p.trn_pos)*phase;
        Hr(:,1) = Hr(:,1) + Hz(1,p.ref_pos)*phase;
        Hr(:,2) = Hr(:,2) + Hz(2,p.ref_pos)*phase;
        Ht(:,1) = Ht(:,1) + Hz(1,p.trn_pos)*phase;
        Ht(:,2) = Ht(:,2) + Hz(2,p.trn_pos)*phase;

        phase = phase .* phase_step;
        maxE(:,n) = max(abs(Ex),[],2);
        probeSig(:,n) = Ex(:,probe_idx);
    end

    out.vac = pack_grid(SN,Er(:,1),Et(:,1),Hr(:,1),Ht(:,1),maxE(1,:),probeSig(1,:));
    out.mat = pack_grid(SN,Er(:,2),Et(:,2),Hr(:,2),Ht(:,2),maxE(2,:),probeSig(2,:));
    out.ade_mode = 'centered_Q';
end

function [R,T,A,diag] = extract_rta_px(out)
    Einc_ref = out.vac.Ex_ref;
    Hinc_ref = out.vac.Hy_ref;
    Einc_trn = out.vac.Ex_trn;
    Hinc_trn = out.vac.Hy_trn;

    Eref = out.mat.Ex_ref - out.vac.Ex_ref;
    Href = out.mat.Hy_ref - out.vac.Hy_ref;
    Etrn = out.mat.Ex_trn;
    Htrn = out.mat.Hy_trn;

    diag.Px_inc_ref = px_flux(Einc_ref,Hinc_ref);
    diag.Px_inc_trn = px_flux(Einc_trn,Hinc_trn);
    diag.Px_ref     = px_flux(Eref,Href);
    diag.Px_trn     = px_flux(Etrn,Htrn);

    R = real(-diag.Px_ref ./ max(abs(diag.Px_inc_ref),eps));
    T = real( diag.Px_trn ./ max(abs(diag.Px_inc_trn),eps));
    A = real(1 - R - T);
end

function [eps_fit,n_tmm,R,T,A] = tmm_reference(p,mat,z0,film_nm)
    if exist('tmm1d_transfer_matrix_reference','file') ~= 2
        error('TMM helper not found. Put tmm1d_transfer_matrix_reference.m in the same folder or on the MATLAB path.');
    end
    eps_fit = eps_pr(p.OMEGA(:),mat);
    n_tmm   = sqrt_branch_passive(eps_fit);
    z_tmm   = z0 ./ n_tmm;

    inc = {ones(size(p.freq_hz)), z0*ones(size(p.freq_hz))};
    [R0,T0,A0,tmmout] = tmm1d_transfer_matrix_reference( ...
        film_nm*1e-9,{n_tmm},{z_tmm},p.freq_hz,inc,inc,0,'TE',false);

    R = interp1(tmmout.lambda_nm(:),R0(:),p.lambda_nm(:),'linear','extrap');
    T = interp1(tmmout.lambda_nm(:),T0(:),p.lambda_nm(:),'linear','extrap');
    A = interp1(tmmout.lambda_nm(:),A0(:),p.lambda_nm(:),'linear','extrap');
end

function err = rta_error_metrics(lambda_nm,Rf,Tf,Af,Rt,Tt,At)
    eR = abs(Rf(:)-Rt(:));
    eT = abs(Tf(:)-Tt(:));
    eA = abs(Af(:)-At(:));
    E = [eR; eT; eA];
    [emax,idx] = max(E);
    n = numel(eR);
    if idx <= n
        ch = 'R'; ii = idx;
    elseif idx <= 2*n
        ch = 'T'; ii = idx-n;
    else
        ch = 'A'; ii = idx-2*n;
    end
    err.Emax_RTA = emax;
    Ef = E(isfinite(E));
    err.Erms_RTA = sqrt(mean(Ef.^2));
    err.Emax_R = max(eR);
    err.Emax_T = max(eT);
    err.Emax_A = max(eA);
    err.max_channel = ch;
    err.max_index = ii;
    err.max_lambda_nm = lambda_nm(ii);
    err.max_error = emax;
end


function write_match_summary(prefix,nominal_err,film_nm)
    fid = fopen([prefix '_match_summary.txt'],'w');
    if fid < 0
        warning('Could not write match summary file.');
        return;
    end
    fprintf(fid,'1D FDTD/TMM single-case match summary\n');
    fprintf(fid,'====================================\n');
    fprintf(fid,'TMM_thickness_nm = %.12g\n', film_nm);
    fprintf(fid,'Emax_RTA = %.16g\n', nominal_err.Emax_RTA);
    fprintf(fid,'Erms_RTA = %.16g\n', nominal_err.Erms_RTA);
    fprintf(fid,'Emax_R = %.16g\n', nominal_err.Emax_R);
    fprintf(fid,'Emax_T = %.16g\n', nominal_err.Emax_T);
    fprintf(fid,'Emax_A = %.16g\n', nominal_err.Emax_A);
    fprintf(fid,'max_channel = %s\n', nominal_err.max_channel);
    fprintf(fid,'max_lambda_nm = %.16g\n', nominal_err.max_lambda_nm);
    fclose(fid);
end

function plot_rta_overlay(lambda_nm,Rf,Tf,Af,Rt,Tt,At,err,title_text,outpng)
    fig = figure('Color','w','Position',[120 120 1150 720],'Visible','on');
    subplot(2,1,1);
    plot(lambda_nm,Rf,'b','LineWidth',1.5); hold on;
    plot(lambda_nm,Rt,'b--','LineWidth',1.2);
    plot(lambda_nm,Tf,'g','LineWidth',1.5);
    plot(lambda_nm,Tt,'r--','LineWidth',1.2);
    plot(lambda_nm,Af,'Color',[0.55 0.3 0.75],'LineWidth',1.5);
    plot(lambda_nm,At,'--','Color',[0.45 0.25 0.20],'LineWidth',1.2);
    grid on; ylabel('R / T / A');
    legend('R FDTD','R TMM','T FDTD','T TMM','A FDTD','A TMM','Location','best');
    title(sprintf('%s | Emax=%.6g | Erms=%.6g', title_text, err.Emax_RTA, err.Erms_RTA), 'Interpreter','none');

    subplot(2,1,2);
    plot(lambda_nm,abs(Rf-Rt),'b','LineWidth',1.3); hold on;
    plot(lambda_nm,abs(Tf-Tt),'Color',[1.0 0.45 0.0],'LineWidth',1.3);
    plot(lambda_nm,abs(Af-At),'g','LineWidth',1.3);
    yl = ylim; line([err.max_lambda_nm err.max_lambda_nm], yl, 'Color','k','LineStyle',':','LineWidth',1.0);
    grid on; xlabel('Wavelength (nm)'); ylabel('Absolute error');
    legend('|Delta R|','|Delta T|','|Delta A|','Location','best');
    saveas(fig,outpng);
end


function s = pack_grid(SN,Er,Et,Hr,Ht,maxE,probe)
    s = struct('SN',SN,'Ex_ref',Er,'Ex_trn',Et,'Hy_ref',Hr,'Hy_trn',Ht, ...
               'max_abs_E_history',maxE,'probe_signal',probe);
end

function Px = px_flux(E,H)
    Px = -0.5*real(E.*conj(H));
end

function mat = load_pr_json(json_file,model_name)
    if ~isfile(json_file), error('JSON file not found: %s',json_file); end
    d = jsondecode(fileread(json_file));

    if iscell(d), d = [d{:}]; end
    if numel(d) > 1
        names = strings(numel(d),1);
        for k = 1:numel(d)
            if isfield(d(k),'name') && ~isempty(d(k).name), names(k) = string(d(k).name); end
        end
        idx = find(names==string(model_name),1);
        if isempty(idx), disp(names); error('Model not found: %s',model_name); end
        d = d(idx);
    end

    if isfield(d,'type') && strcmp(string(d.type),'PoleResidue')
        [a,c] = parse_poles(d.poles);
        if isfield(d,'name'), mat.material_name = string(d.name); else, mat.material_name = string(model_name); end
        mat.eps_inf = d.eps_inf;
    elseif isfield(d,'model_class') && strcmp(string(d.model_class),'TIDY3D_POLE_RESIDUE')
        P = d.poles;
        a = zeros(numel(P),1); c = a;
        for j = 1:numel(P)
            a(j) = P(j).a_real + 1i*P(j).a_imag;
            c(j) = P(j).c_real + 1i*P(j).c_imag;
        end
        if isfield(d,'material_name'), mat.material_name = string(d.material_name); else, mat.material_name = string(model_name); end
        mat.eps_inf = d.eps_inf;
    else
        error('Unsupported JSON format. Expected native Tidy3D PoleResidue or MATLAB PoleResidue export.');
    end

    mat.a_half = a(:);
    mat.c_half = c(:);
    mat.npoles_half = numel(mat.a_half);
    mat.a_full = [mat.a_half; conj(mat.a_half)];
    mat.c_full = [mat.c_half; conj(mat.c_half)];
    mat.naux = numel(mat.a_full);
end

function [a,c] = parse_poles(P)
    a = [];
    c = [];
    if iscell(P)
        for j = 1:numel(P)
            pair = P{j};
            if iscell(pair)
                a(end+1,1) = zval(pair{1}); %#ok<AGROW>
                c(end+1,1) = zval(pair{2}); %#ok<AGROW>
            else
                a(end+1,1) = zval(pair(1)); %#ok<AGROW>
                c(end+1,1) = zval(pair(2)); %#ok<AGROW>
            end
        end
    elseif isstruct(P)
        sz = size(P);
        if numel(P)==2 && (sz(1)==1 || sz(2)==1)
            a = zval(P(1)); c = zval(P(2));
        elseif numel(sz)==2 && sz(2)==2
            for j = 1:sz(1)
                a(end+1,1) = zval(P(j,1)); %#ok<AGROW>
                c(end+1,1) = zval(P(j,2)); %#ok<AGROW>
            end
        elseif numel(sz)==2 && sz(1)==2
            for j = 1:sz(2)
                a(end+1,1) = zval(P(1,j)); %#ok<AGROW>
                c(end+1,1) = zval(P(2,j)); %#ok<AGROW>
            end
        elseif mod(numel(P),2)==0
            F = reshape(P,1,[]);
            for k = 1:2:numel(F)
                a(end+1,1) = zval(F(k)); %#ok<AGROW>
                c(end+1,1) = zval(F(k+1)); %#ok<AGROW>
            end
        else
            error('Unsupported PoleResidue poles layout after jsondecode.');
        end
    else
        error('Unsupported poles container type.');
    end
end

function z = zval(s)
    if iscell(s), s = s{1}; end
    z = s.real + 1i*s.imag;
end

function e = eps_pr(omega,mat)
    omega = omega(:);
    e = mat.eps_inf*ones(size(omega));
    for j = 1:mat.npoles_half
        a = mat.a_half(j);
        c = mat.c_half(j);
        e = e - c./(1i*omega+a) - conj(c)./(1i*omega+conj(a));
    end
end

function n = sqrt_branch_passive(eps)
% sqrt_branch_passive  Robust square root for passive/near-passive dispersive media.
%
% For a causal passive material Im(eps) >= 0, the physical branch is
%   Re(n) >= 0  and  Im(n) >= 0.
% MATLAB's sqrt() chooses the branch with Im(sqrt) >= 0, which is correct
% when Im(eps) > 0.  When Im(eps) passes through zero (lossless bands or
% near-passive fits with small negative Im(eps)), the branch can flip and
% Re(n) becomes negative.  This function enforces the physical branch
% continuously across the spectrum:
%
%   Step 1: take sqrt(eps) with MATLAB's default branch (Im >= 0).
%   Step 2: flip any point where Im(n) < 0  (handles Im(eps)<0 cases).
%   Step 3: flip any point where Re(n) < 0  (handles branch-cut crossing
%           near Im(eps)=0 that left Im(n)>=0 but Re(n)<0).
%   Step 4: continuity repair — if a sign flip creates a discrete jump
%           larger than the local smooth variation, undo it.
%
% This is safe for metals (Re(eps)<0 over a band) because for metals the
% correct branch has Re(n)>0, Im(n)>0, which steps 1-3 already select.

    eps = eps(:);
    n   = sqrt(eps);

    % Step 2: standard passive branch fix
    neg_im = imag(n) < 0;
    n(neg_im) = -n(neg_im);

    % Step 3: fix Re(n)<0 that can appear when Im(eps) crosses zero
    neg_re = real(n) < 0;
    n(neg_re) = -n(neg_re);

    % Step 4: continuity check — scan for large discrete jumps and repair.
    % A jump is suspicious when |Delta Re(n)| > 3 * local median variation.
    re_n  = real(n);
    im_n  = imag(n);
    dre   = abs(diff(re_n));
    dim   = abs(diff(im_n));
    med_dre = max(median(dre), 1e-6);
    med_dim = max(median(dim), 1e-6);

    for k = 1:numel(n)-1
        re_jump = dre(k) > 6 * med_dre;
        im_jump = dim(k) > 6 * med_dim;
        if re_jump || im_jump
            % Try flipping point k+1; keep if it reduces the jump.
            n_try = n;
            n_try(k+1) = -n_try(k+1);
            dre_try = abs(real(n_try(k+1)) - real(n_try(k)));
            dim_try = abs(imag(n_try(k+1)) - imag(n_try(k)));
            if dre_try < dre(k) && dim_try <= dim(k) + med_dim
                n = n_try;
                re_n = real(n);
                im_n = imag(n);
                dre  = abs(diff(re_n));
                dim  = abs(diff(im_n));
            end
        end
    end
end

function cpml = make_no_cpml_1d(KE)
    cpml = struct('kEi',ones(1,KE),'kHi',ones(1,KE-1), ...
                  'bE',ones(1,KE),'cE',zeros(1,KE), ...
                  'bH',ones(1,KE-1),'cH',zeros(1,KE-1));
end

function cpml = make_cpml_1d(KE,npml,dx,dt,eps0,mu0,m,R0)
    eta0 = sqrt(mu0/eps0);
    sigma_max = -(m+1)*log(R0)/(2*eta0*npml*dx);

    sigE = zeros(1,KE);
    sigH = zeros(1,KE-1);
    kapE = ones(1,KE);
    kapH = ones(1,KE-1);

    for i = 1:npml
        xE = (npml-i+1)/npml;
        sigE(i) = sigma_max*xE^m;
        sigE(KE-i+1) = sigE(i);

        if i <= npml-1
            xH = (npml-i+0.5)/npml;
            sigH(i) = sigma_max*xH^m*(mu0/eps0);
            sigH(KE-i) = sigH(i);
        end
    end

    bE = exp(-(sigE./kapE)*(dt/eps0));
    bH = exp(-(sigH./kapH)*(dt/mu0));
    cE = zeros(1,KE);
    cH = zeros(1,KE-1);
    ie = sigE > 0;
    ih = sigH > 0;
    cE(ie) = (bE(ie)-1)./kapE(ie);
    cH(ih) = (bH(ih)-1)./kapH(ih);

    cpml = struct('kEi',1./kapE,'kHi',1./kapH, ...
                  'bE',bE,'cE',cE,'bH',bH,'cH',cH);
end
