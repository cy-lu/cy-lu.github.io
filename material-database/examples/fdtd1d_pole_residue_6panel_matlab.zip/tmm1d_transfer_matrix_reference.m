function [R_calc, T_calc, A_calc, out] = tmm1d_transfer_matrix_reference(d, n_eff_list, z_eff_list, freq, incident_medium, substrate_medium, angle, polarization, doPlot)
%TMM1D_TRANSFER_MATRIX_REFERENCE  Transfer-matrix reference for 1D FDTD tests.
%
% Purpose
%   Computes R/T/A for a stack of homogeneous planar layers.  This helper is
%   used by fdtd1d_pole_residue_softadd_optional_tmm.m when the optional TMM
%   comparison is enabled.
%
% Inputs
%   d                : layer thickness vector [m]
%   n_eff_list       : cell array of refractive-index spectra for layers
%   z_eff_list       : cell array of impedance spectra for layers
%   freq             : frequency vector [Hz]
%   incident_medium  : {n_inc, z_inc}
%   substrate_medium : {n_sub, z_sub}
%   angle            : incident angle [degree], default 0
%   polarization     : 'TE' or 'TM', default 'TE'
%   doPlot           : true/false, default false
%
% Outputs
%   R_calc, T_calc, A_calc : reflectance, transmittance, absorptance
%   out                    : intermediate spectra and transfer matrices
%
% Notes
%   Use freq = omega/(2*pi) if the source data are stored in angular
%   frequency.  Output spectra are sorted by increasing wavelength.
%
    if nargin < 7 || isempty(angle)
        angle = 0;
    end
    if nargin < 8 || isempty(polarization)
        polarization = 'TE';
    end
    if nargin < 9 || isempty(doPlot)
        doPlot = false;
    end

    c = 2.99792458e8;
    angle_rad = deg2rad(angle);

    freq = freq(:).';
    num_freq = numel(freq);
    num_layers = numel(d) + 2;

    if numel(n_eff_list) ~= numel(d) || numel(z_eff_list) ~= numel(d)
        error('n_eff_list and z_eff_list must have the same length as d.');
    end

    % Wave number in vacuum
    k0 = 2.0 * pi * freq / c;
    % In-plane wave-vector component
    k_parallel = k0 * sin(angle_rad);

    % Build arrays for each layer's (n, z)
    N = zeros(num_layers, num_freq);
    Z = zeros(num_layers, num_freq);

    N(1, :)   = reshape(incident_medium{1}, 1, []);
    Z(1, :)   = reshape(incident_medium{2}, 1, []);
    N(end, :) = reshape(substrate_medium{1}, 1, []);
    Z(end, :) = reshape(substrate_medium{2}, 1, []);

    for i = 1:numel(d)
        N(i + 1, :) = reshape(n_eff_list{i}, 1, []);
        Z(i + 1, :) = reshape(z_eff_list{i}, 1, []);
    end

    % kz for each layer and frequency
    k0_layers = N .* k0;
    kz_layers = sqrt(k0_layers.^2 - k_parallel.^2);

    % Precompute boundary matrices and phase matrices
    B_list = cell(1, num_layers - 1);
    P_list = cell(1, num_layers - 1);

    for i = 1:(num_layers - 1)
        kz_b   = kz_layers(i, :);
        kz_bp1 = kz_layers(i + 1, :);

        u_b   = N(i, :)     .* Z(i, :);
        u_bp1 = N(i + 1, :) .* Z(i + 1, :);

        if strcmpi(polarization, 'TE')
            r_i = (kz_b ./ u_b - kz_bp1 ./ u_bp1) ./ (kz_b ./ u_b + kz_bp1 ./ u_bp1);
            t_i = (2.0 * kz_b ./ u_b) ./ (kz_b ./ u_b + kz_bp1 ./ u_bp1);
        elseif strcmpi(polarization, 'TM')
            r_i = (u_bp1 .* kz_b - u_b .* kz_bp1) ./ (u_b .* kz_bp1 + u_bp1 .* kz_b);
            t_i = (2.0 * u_bp1 .* kz_b) ./ (u_b .* kz_bp1 + u_bp1 .* kz_b);
        else
            error('polarization must be ''TE'' or ''TM''.');
        end

        B_layer = zeros(2, 2, num_freq);
        B_layer(1, 1, :) = 1.0 ./ t_i;
        B_layer(1, 2, :) = r_i ./ t_i;
        B_layer(2, 1, :) = r_i ./ t_i;
        B_layer(2, 2, :) = 1.0 ./ t_i;
        B_list{i} = B_layer;

        if i < num_layers - 1
            phase = kz_bp1 .* d(i);
            P_layer = zeros(2, 2, num_freq);
            P_layer(1, 1, :) = exp(-1i * phase);
            P_layer(2, 2, :) = exp( 1i * phase);
            P_list{i} = P_layer;
        else
            P_list{i} = [];
        end
    end

    % Initialize global transfer matrix as identity
    M = zeros(2, 2, num_freq);
    M(1, 1, :) = 1.0;
    M(2, 2, :) = 1.0;

    % Sequential multiplication
    for i = 1:(num_layers - 1)
        M = multiply_2x2(M, B_list{i});
        if i < num_layers - 1
            M = multiply_2x2(M, P_list{i});
        end
    end

    % Reflection / Transmission amplitudes
    r_total = squeeze(M(2, 1, :) ./ M(1, 1, :)).';
    t_total = squeeze(1.0 ./ M(1, 1, :)).';

    kz_inc = kz_layers(1, :);
    kz_sub = kz_layers(end, :);

    R_calc = abs(r_total).^2;
    T_calc = abs(t_total).^2 .* (real(kz_sub) ./ real(kz_inc));
    A_calc = 1.0 - R_calc - T_calc;

    % Enforce final output order as wavelength increasing: short -> long
    lambda_nm = (c ./ freq) * 1e9;
    [lambda_nm, sort_idx] = sort(lambda_nm, 'ascend');

    freq      = freq(sort_idx);
    r_total   = r_total(sort_idx);
    t_total   = t_total(sort_idx);
    R_calc    = R_calc(sort_idx);
    T_calc    = T_calc(sort_idx);
    A_calc    = A_calc(sort_idx);

    N         = N(:, sort_idx);
    Z         = Z(:, sort_idx);
    kz_layers = kz_layers(:, sort_idx);
    M         = M(:, :, sort_idx);

    out = struct();
    out.N = N;
    out.Z = Z;
    out.kz_layers = kz_layers;
    out.r_total = r_total;
    out.t_total = t_total;
    out.M = M;
    out.freq = freq;
    out.lambda_nm = lambda_nm;
    out.sort_idx = sort_idx;

    if doPlot
        figure('Color', 'w');

        subplot(2, 2, 1);
        plot(lambda_nm, T_calc, 'r', 'LineWidth', 1.5);
        xlabel('Wavelength (nm)'); ylabel('Transmittance');
        ylim([0, 1]); grid on; legend('Transmittance', 'Location', 'best');

        subplot(2, 2, 2);
        plot(lambda_nm, R_calc, 'b', 'LineWidth', 1.5);
        xlabel('Wavelength (nm)'); ylabel('Reflectance');
        ylim([0, 1]); grid on; legend('Reflectance', 'Location', 'best');

        subplot(2, 2, 3);
        plot(lambda_nm, A_calc, 'g', 'LineWidth', 1.5);
        xlabel('Wavelength (nm)'); ylabel('Absorptance');
        ylim([0, 1]); grid on; legend('Absorptance', 'Location', 'best');

        subplot(2, 2, 4);
        plot(lambda_nm, T_calc, 'r', 'LineWidth', 1.5); hold on;
        plot(lambda_nm, R_calc, 'b', 'LineWidth', 1.5);
        plot(lambda_nm, A_calc, 'g', 'LineWidth', 1.5);
        xlabel('Wavelength (nm)'); ylabel('Values');
        ylim([0, 1]); grid on; legend('T', 'R', 'A', 'Location', 'best');
    end
end

function out = multiply_2x2(A, B)
% Multiply two batches of 2x2 matrices over the 3rd dimension
    out = zeros(size(A));
    out(1,1,:) = A(1,1,:).*B(1,1,:) + A(1,2,:).*B(2,1,:);
    out(1,2,:) = A(1,1,:).*B(1,2,:) + A(1,2,:).*B(2,2,:);
    out(2,1,:) = A(2,1,:).*B(1,1,:) + A(2,2,:).*B(2,1,:);
    out(2,2,:) = A(2,1,:).*B(1,2,:) + A(2,2,:).*B(2,2,:);
end
